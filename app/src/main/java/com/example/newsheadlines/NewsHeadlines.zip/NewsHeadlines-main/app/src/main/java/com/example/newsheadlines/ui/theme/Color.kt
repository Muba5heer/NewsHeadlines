package com.example.newsheadlines.ui.theme

import androidx.compose.ui.graphics.Color

val Purple200 = Color(0xFFBB86FC)
val Purple500 = Color(0xCE00BCD4)
val Purple700 = Color(0xFF4CAF50)
val Teal200 = Color(0xFF03DAC5)
val red200 = Color(0xFFF1082B)